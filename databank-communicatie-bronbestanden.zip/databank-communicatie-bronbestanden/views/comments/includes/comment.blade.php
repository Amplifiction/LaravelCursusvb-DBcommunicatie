<blockquote class="comment">
    <q class="comment-content">Comment content. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Et quo delectus magnam, fuga nostrum amet quam, rem quia praesentium, tempore dolores. Libero aliquam molestias magnam atque optio. Error, culpa iure!</q>
    <cite class="comment-cite">John Doe</cite>
    <div class="comment-actions">
        <a href="/comments/id/edit">edit</a> or delete
    </div>
</blockquote>
