<article class="post-small">
    <h1 class="post-small-title"><a href="/posts/id">Post title</a></h1>
    <p class="post-small-subtitle">Post subtitle</p>
    <div class="post-small-content">
        Post Content truncated. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores magni facere
        quidem, at sequi ad quis quibusdam quos accusamus ea....
    </div>
    <footer>
        <a class="post-small-readmore" href="/posts/id">Read more &rarr;</a>
    </footer>
</article>
