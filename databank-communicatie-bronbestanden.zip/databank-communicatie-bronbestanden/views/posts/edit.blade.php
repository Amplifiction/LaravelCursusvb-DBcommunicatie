@extends('layouts.default')

@section('title', 'Edit post')

@section('content')
    <section>
        <h2>Edit post</h2>

        <form action="/posts/id" method="post">
            @include('posts.includes.form', ['buttonText' => "Update"])
        </form>
    </section>
@endsection
