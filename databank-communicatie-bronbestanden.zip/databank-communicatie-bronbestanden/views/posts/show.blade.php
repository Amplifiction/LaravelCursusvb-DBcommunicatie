@extends('layouts.default')

@section('title', 'Post title')

@section('content')
    <section class="post-details">
        <header class="post-header">
            <h2 class="post-title">Post title</h2>
            <p class="post-subtitle">Post subtitle</p>
        </header>

        <div class="post-actions">
            <a href="/posts/id/edit">Edit this post</a> or
            <span>Delete this post</span>
        </div>

        <div>
            Post content. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eos quo sequi illum voluptatum rem a repudiandae, consequuntur sunt modi expedita quis obcaecati quae dolor pariatur maiores ipsam dicta assumenda dolore odio autem laboriosam. Odio delectus, saepe eveniet debitis accusantium rem dignissimos veniam consequuntur illo praesentium esse nesciunt recusandae excepturi, facilis, ducimus harum aut maxime magnam. Laborum quisquam consequuntur maiores!
        </div>

        <aside class="comments">
            <h3>Comments</h3>
            <div class="comment-section">
                <div class="comment-form">
                    <form action="/comments/store" method="post">
                        @include('comments.includes.form', ['buttonText' => "Add comment"])
                    </form>
                </div>
                <div class="comments-list">
                    @include('comments.includes.comment')
                    @include('comments.includes.comment')
                    @include('comments.includes.comment')
                </div>
            </div>
        </aside>
    </section>
@endsection
