@extends('layouts.default')

@section('title', 'Posts')

@section('content')
    <section>
        <h2>Posts</h2>
        <div class="posts-list">
            @include('posts.includes.post-small')
            @include('posts.includes.post-small')
            @include('posts.includes.post-small')
            @include('posts.includes.post-small')
            @include('posts.includes.post-small')
            @include('posts.includes.post-small')
        </div>
        <div class="pagination">
            Previous ... 1 2 3 ... Next
        </div>
    </section>
@endsection
