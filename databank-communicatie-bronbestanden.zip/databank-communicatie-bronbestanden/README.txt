De controller files plaats je in de map "App/Http/Controllers".
De migration files plaats je in de map "database/migrations".
De web route file plaats je in de map "routes".
De styles map plaats je in de map "public".
De views map plaats je in de map "resources".